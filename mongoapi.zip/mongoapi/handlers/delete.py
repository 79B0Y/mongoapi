from flask import jsonify

def handle(request, client):
    data = request.get_json()
    db = client[data['database']]
    col = db[data['collection']]
    result = col.delete_many(data['filter'])
    return jsonify({"deleted_count": result.deleted_count})