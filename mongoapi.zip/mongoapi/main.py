from flask import Flask, request, jsonify
from pymongo import MongoClient
from .config_loader import load_config
from .handlers import insert, find, update, delete, upsert, aggregate

def run():
    config = load_config()
    client = MongoClient(config["mongodb"]["uri"])
    app = Flask(__name__)

    @app.route('/insert', methods=['POST'])
    def insert_route(): return insert.handle(request, client)

    @app.route('/find', methods=['POST'])
    def find_route(): return find.handle(request, client)

    @app.route('/update', methods=['POST'])
    def update_route(): return update.handle(request, client)

    @app.route('/delete', methods=['POST'])
    def delete_route(): return delete.handle(request, client)

    @app.route('/upsert', methods=['POST'])
    def upsert_route(): return upsert.handle(request, client)

    @app.route('/aggregate', methods=['POST'])
    def aggregate_route(): return aggregate.handle(request, client)

    app.run(host=config["server"]["host"], port=config["server"]["port"])